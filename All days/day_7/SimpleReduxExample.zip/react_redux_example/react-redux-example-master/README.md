# React Redux Example

A small and simple example app, demonstrating how to use react and redux for building webapps.

[![Build Status](https://img.shields.io/travis/dasniko/react-redux-example.svg)](https://travis-ci.org/dasniko/react-redux-example)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/dasniko/react-redux-example/blob/master/LICENSE)
