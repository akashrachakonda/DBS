```
> npm install
> npm start
```
