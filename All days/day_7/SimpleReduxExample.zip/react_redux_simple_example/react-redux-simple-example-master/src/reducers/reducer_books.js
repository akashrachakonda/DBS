export default function () {
    return [
        {'title': 'Book1'},
        {'title': 'Book2'},
        {'title': 'Book3'},
        {'title': 'Book4'}
    ]
}